const express = require('express');
const fs = require('fs');
const app = express();
const port = 5000;


app.use(express.json());
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    //res.setHeader('Vary', 'origin')
    next();
  });

// Rota para lidar com requisições POST para "/cadastros"
app.post('/cadastros', (req, res) => {

  const novoCadastro = req.body;
  console.log(novoCadastro)

  // Carregar cadastros existentes do arquivo JSON
  const cadastros = JSON.parse(fs.readFileSync('bd.json'));

  // Adicionar novo cadastro aos cadastros existentes
  cadastros.push(novoCadastro);

  // Salvar cadastros atualizados no arquivo JSON
  fs.writeFileSync('bd.json', JSON.stringify(cadastros, null, 2));

res.json({ message: 'Cadastro realizado com sucesso' });
});

// Rota para lidar com requisições GET para "/cadastros"
app.get('/cadastros', (req, res) => {
  // Carregar cadastros do arquivo JSON
  const cadastros = JSON.parse(fs.readFileSync('bd.json'));
  //res.json(clientes);
  res.json(cadastros);
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});