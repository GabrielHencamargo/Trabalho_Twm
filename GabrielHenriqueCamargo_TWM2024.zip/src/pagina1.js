import React from "react";
function pagina1() {
    return(
        <div>
            <h1>AAAAAAAAAa</h1>
        </div>
    )
}
export default pagina1;