import React,{useState,useEffect,createContext, useContext} from "react";
import "./App.css";
import { useDispatch,useSelector } from "react-redux";
import { adicionarpedido } from "./store/actions/pedidoaction";


export let chamadas = []


export function Seguro(){
    const [Equip, setEquip] = useState('');
    const [Nome, setNome] = useState('');
    const [Email, setEmail] = useState('');
    const [Tel, setTel] = useState('');
    const [insereCliente, setInsereCliente] = useState(false);

const handleSubmit = (e) => {
    e.preventDefault();

    const cliente = {
        nome: Nome,
        email: Email,
        telefone: Tel,
        seguro: Equip
    };

    fetch("http://localhost:5000/cadastros", {
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        },
        method: "POST",
        body: JSON.stringify(cliente)
    })
    .then((response) => response.json())
    .then((data) => {
        console.log("DATA", data);
    })
    .catch((error) => {
        console.log("Isso é um erro", error);
    });

    setInsereCliente(false);
};

useEffect(() => {
    if (insereCliente) {
        console.log("Insere cliente");
        handleSubmit();
    }
}, [insereCliente]);

return (
    <div className="background_seguro">
        <nav className="loginhome"><a href="Home">Inicio</a></nav>

        <div className = "main_frame">

            <div className = "centralized_box2">

                <div className="titulo2">
                    Acionar o seguro!!!
                </div>
                <small className="subticadastro"> Resolvemos entre 30 e 30000 dias!!</small>
                <form onSubmit={handleSubmit}>
    <input 
        type="text" 
        placeholder="Nome" 
        value={Nome} 
        onChange={(e) => setNome(e.target.value)} 
    />
    <input 
        type="email" 
        placeholder="Email" 
        value={Email} 
        onChange={(e) => setEmail(e.target.value)} 
    />
    <input 
        type="tel" 
        placeholder="Telefone" 
        value={Tel} 
        onChange={(e) => setTel(e.target.value)} 
    />
    <input 
        type="text" 
        placeholder="Equipamento" 
        value={Equip} 
        onChange={(e) => setEquip(e.target.value)} 
    />
    <button type="submit">Enviar</button>
</form>
            </div>
        </div>
    </div>
  );
}
