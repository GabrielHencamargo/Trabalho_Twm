// src/store/reducers/index.js
import { combineReducers } from 'redux';
import pedidosReducer from './pedidoreducer';

const rootReducer = combineReducers({
  pedido: pedidosReducer,
  // Adicione outros redutores aqui, se necessário
});

export default rootReducer;