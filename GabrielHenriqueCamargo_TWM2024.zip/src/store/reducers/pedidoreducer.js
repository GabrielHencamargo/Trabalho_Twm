// src/store/reducers/pedidoreducer.js
const initialState = {
  pedidos: []
};

const pedidosReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'ADICIONAR_PEDIDO':
      return {
        ...state,
        pedido: [...state.pedidos, action.payload]
      };
    default:
      return state;
  }
};

export default pedidosReducer;