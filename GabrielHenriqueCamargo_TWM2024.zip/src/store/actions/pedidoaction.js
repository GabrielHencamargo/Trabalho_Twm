// src/store/actions/nomesactions.js
export const adicionarpedido = (pedido) => ({
    type: 'ADICIONAR_PEDIDO',
    payload: pedido
  });